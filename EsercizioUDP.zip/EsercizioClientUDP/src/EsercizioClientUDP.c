/*
 ============================================================================
 Name        : ClientUDP.c
 Author      : Ester Molinari
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : Simple UDP client for string vowels removal
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#define ECHOMAX 255
#define PORT 48000

void errorHandler(char* errorMessage) {
	printf(errorMessage);
}

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

int main(void) {

	// just for output stream
	setvbuf(stdout, NULL, _IONBF, 0);

#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if (iResult != 0) {
		printf("error at WSAStartup\n");
		return EXIT_FAILURE;
	}
#endif

	int sock;
	struct sockaddr_in echoServAddr;
	struct sockaddr_in fromAddr;
	unsigned int fromSize;
	char echoString[ECHOMAX];
	char echoBuffer[ECHOMAX];
	int echoStringLen;
	int respStringLen;

	// client's socket
	if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		errorHandler("socket() failed");
	}

	// server's address
	char server_name[ECHOMAX], server_ip[16];
	int server_port = 0;

	printf("Insert server's name\n");
	scanf("%s", server_name);
	printf("Insert a port number\n");
	scanf("%d", &server_port);

	struct hostent *server;
	struct in_addr *ina;

	// server's name resolution (ip)
	server = gethostbyname(server_name);
	if (server == NULL) {
		errorHandler("gethostbyname() failed\n");
		return EXIT_FAILURE;
	} else {
		ina = (struct in_addr*)server->h_addr_list[0];
	}

	// setting server's address
	memset(&echoServAddr, 0, sizeof(echoServAddr));
	echoServAddr.sin_family = PF_INET;
	echoServAddr.sin_port = htons(server_port);
	echoServAddr.sin_addr.s_addr = inet_addr(inet_ntoa(*ina));

	// sending hello to the server
	char hello[5];
	strcpy(hello, "hello");

	if (sendto(sock, hello, strlen(hello), 0, (struct sockaddr*)&echoServAddr, sizeof(echoServAddr)) != strlen(hello)) {
		errorHandler("sento() sent different number of bytes than expected");
	} else {
		printf("Connected to %s:%d (%s)\n", inet_ntoa(*ina), htons(echoServAddr.sin_port), server_name);
	}

	// sending a string to the server
	memset(echoString, 0, sizeof(echoString)); // cleans buffer
	printf("Insert echo string:\n");
	scanf("%s", echoString);

	if ((echoStringLen = strlen(echoString)) > ECHOMAX) {
		errorHandler("echo word too long");
	}

	echoStringLen = strlen(echoString);
	if (sendto(sock, echoString, echoStringLen, 0, (struct sockaddr*)&echoServAddr, sizeof(echoServAddr)) != echoStringLen) {
		errorHandler("sendto() sent different number of bytes than expected");
	}

	// receiving result from the server
	fromSize = sizeof(fromAddr);
	respStringLen = recvfrom(sock, echoBuffer, ECHOMAX, 0, (struct sockaddr*)&fromAddr, &fromSize);

	if (echoServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr) {
		fprintf(stderr, "Error: received a packet from unknown source.\n");
		exit(EXIT_FAILURE);
	}

	echoBuffer[respStringLen] = '\0'; // FIXME useful?

	// finding server's name by address
	struct in_addr addr;
	struct hostent* host;
	addr.s_addr = fromAddr.sin_addr.s_addr; // taking ip address of server

	host = gethostbyaddr((char*)&fromAddr.sin_addr, 4, AF_INET);
	char* canonical_name = host->h_name;
	printf("Received '%s' from server: %s, address: %s\n", echoBuffer, canonical_name, inet_ntoa(addr));

	// closing and exit
	closesocket(sock);
	clearwinsock();
	system("pause");

	return EXIT_SUCCESS;
}

