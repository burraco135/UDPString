/*
 ============================================================================
 Name        : EsercizioServerUDP.c
 Author      : Ester Molinari
 Version     : 1.0
 Copyright   : Your copyright notice
 Description : Simple UDP server for string vowels removal
 ============================================================================
 */

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#define ECHOMAX 255
#define PORT 48000

void errorHandler(char* errorMessage) {
	printf(errorMessage);
}

void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

// removes vowels from an input string
void vowelRemover(int stringLen, char string[]) {
	int count = 0; // vowel counter

	for (int i = 0; i < stringLen; i++) {
		if (string[i] != 'a' && string[i] != 'e' && string[i] != 'i' && string[i] != 'o' && string[i] != 'u'
				&& string[i] != 'A' && string[i] != 'E' && string[i] != 'I' && string[i] != 'O' && string[i] != 'U') {
			string[count++] = string[i];
		}
	}
	string[count] = '\0';
}

int main(void) {
	// forces output stream
	setvbuf(stdout, NULL, _IONBF, 0);

#if defined WIN32
	WSADATA wsaData;
	int iResult = WSAStartup(MAKEWORD(2,2), &wsaData);
	if (iResult != 0) {
		printf("error at WSAStartup\n");
		return EXIT_FAILURE;
	}
#endif

	int server_socket;
	struct sockaddr_in echoServerAddr;
	struct sockaddr_in echoClientAddr;
	unsigned int clientAddrLen;
	char echoBuffer[ECHOMAX];
	int recvMsgSize = 0;

	// server's socket
	if ((server_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0) {
		errorHandler("socket() failed");
		return EXIT_FAILURE;
	}

	// server's address
	memset(&echoServerAddr, 0, sizeof(echoServerAddr));
	echoServerAddr.sin_family = AF_INET;
	echoServerAddr.sin_port = htons(PORT);
	echoServerAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	// socket binding
	if ((bind(server_socket, (struct sockaddr*)&echoServerAddr, sizeof(echoServerAddr))) < 0) {
		errorHandler("bind() failed");
		return EXIT_FAILURE;
	}

	// client name
	struct in_addr addr;
	struct hostent* host;

	char hello[ECHOMAX] = "hello";

	// receiving a string from client
	while(1) {

		// welcoming client (receiving 'hello' from client)
		clientAddrLen = sizeof(echoClientAddr);
		memset(echoBuffer, 0, sizeof(echoBuffer)); // cleans buffer
		recvMsgSize = recvfrom(server_socket, echoBuffer, ECHOMAX, 0, (struct sockaddr*)&echoClientAddr, &clientAddrLen);

		// handling client request
		if (strcmp(echoBuffer, hello) == 0) {
			clientAddrLen = sizeof(echoClientAddr);
			memset(echoBuffer, 0, sizeof(echoBuffer)); // cleans buffer
			recvMsgSize = recvfrom(server_socket, echoBuffer, ECHOMAX, 0, (struct sockaddr*)&echoClientAddr, &clientAddrLen);

			// finding client's canonical name
			host = gethostbyaddr((char*)&echoClientAddr.sin_addr, 4, AF_INET);
			addr.s_addr = echoClientAddr.sin_addr.s_addr; // taking ip address from client
			char* canonical_name = host->h_name;

			// printing client info and string received
			printf("Data received from: %s, address: %s\n", canonical_name, inet_ntoa(addr));
			printf("Received '%s', ", echoBuffer);

			// removing vowels
			int bufferLen = strlen(echoBuffer);
			vowelRemover(bufferLen, echoBuffer);

			bufferLen = strlen(echoBuffer);
			printf("sent: '%s'\n", echoBuffer);

			// sending result to client
			if (sendto(server_socket, echoBuffer, bufferLen, 0, (struct sockaddr*)&echoClientAddr, &clientAddrLen) != bufferLen) {
				errorHandler("sendto() sent different number of bytes than expected");
			}
		}

	}
}
